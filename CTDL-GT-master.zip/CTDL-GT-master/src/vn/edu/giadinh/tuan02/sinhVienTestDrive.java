package vn.edu.giadinh.tuan02;

public class sinhVienTestDrive {

    public static void main(String[] args) {
        SinhVien sinhVien;
        sinhVien =  new SinhVien();
        sinhVien.mssv = "2010110039";
        sinhVien.tenSinhVien = "Nguyễn Văn Hoàng";
        sinhVien.tuoi = 19;
        sinhVien.queQuan = "Bình Dương";
        sinhVien.inThongTinSV();
    }
    
}
