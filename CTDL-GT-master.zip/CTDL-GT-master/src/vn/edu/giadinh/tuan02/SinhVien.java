package vn.edu.giadinh.tuan02;



public class SinhVien {


    //1. thuộc tính
    String mssv;
    String tenSinhVien;
    int tuoi;
    String queQuan;
    


    //2. phương thức 
    void inThongTinSV(){
        System.out.println("Mã số Sinh Vien:  " + mssv);
        System.out.println("Tên sinh viên  " + tenSinhVien);
        System.out.println("Tuổi sinh viên:  " + tuoi);
        System.out.println("Quê quán Sinh Vien:  " + queQuan);
        
        
    }
}
